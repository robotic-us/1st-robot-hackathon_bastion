P-Vector 10-degree motion
=========================

Ready-made file
---------------
Motions/motion_04.csv

Motion definition
-----------------
- Motion slot / MS ID: 4
- Motion name: ROTATE10
- Controlled motor: MD0 (first motor)
- P0: absolute 0.0 deg for 300 ms (initial settling)
- P1: absolute +10.0 deg over 1000 ms
- P2: hold absolute +10.0 deg for 1000 ms
- Acceleration/deceleration parameters: 0, 0
- All other motors: not commanded ('-')

Important
---------
The first P-Vector value yd is an ABSOLUTE output-shaft angle relative to the
neutral posture, not a relative displacement. Therefore, to rotate +10 degrees
from a current absolute angle q, use target yd = q + 10.

Example generator commands
--------------------------
1) MD0: 0 deg -> +10 deg
   python tools/make_10deg_motion.py --output motion_04.csv

2) MD1: 25 deg -> 35 deg
   python tools/make_10deg_motion.py --output motion_04.csv --motor 1 --start 25 --delta 10

3) MD0: 0 deg -> -10 deg in 2 seconds
   python tools/make_10deg_motion.py --output motion_04.csv --delta -10 --move-ms 2000

The .memo.json files in the uploaded examples contain robot-specific zero
snapshots. They are intentionally not generated here. Import/save the CSV in
the motion software so that the software can create metadata for the connected
robot, if required.
